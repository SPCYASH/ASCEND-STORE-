# ASCEND. — Setup Guide (Android + Acode)

## Part 1 — Architecture

```
ascend/
├── README.md                 <- this guide
├── site/                     <- the website (static, free hosting)
│   ├── index.html            main storefront
│   ├── styles.css            all styling
│   ├── script.js             menu, animations, checkout dialog
│   ├── config.js             YOUR settings (API address, contact email)
│   ├── success.html / .js    order page: confirms payment, gives download
│   ├── privacy.html  terms.html  refund.html  legal.js
│   ├── favicon.svg  og-image.png  robots.txt
│   └── _headers              security headers (Cloudflare Pages / Netlify)
└── worker/                   <- the backend (Cloudflare Worker)
    ├── src/index.js          orders, webhook, private PDF delivery
    ├── schema.sql            database tables
    └── wrangler.toml         optional CLI config
```

**Payment flow**

1. Buyer clicks Buy → enters email → Worker creates a Razorpay order for ₹149 (price is fixed on the server).
2. Razorpay's secure window opens (UPI apps / QR).
3. Razorpay sends a **signed webhook** to the Worker. The Worker verifies the signature, then checks order ID, amount (14900 paise), currency INR and status `captured`. Only then is the order marked `paid`.
4. The order page asks the **server** for status. Only a `paid` order can request a download link.
5. Download link: random, hashed in the database, valid 10 minutes, max 5 uses. The PDF streams from **private** R2 storage. It is never in the website files.
6. Duplicate webhooks are ignored; "created → paid" is a single atomic update.

**Checkout stays disabled** until `API_BASE` is set in `config.js` AND the Worker has all three secrets. Until then, Buy buttons show "Checkout is not active yet".

## Part 2 — Run it in Acode

1. Copy the `ascend` folder to your phone (for example `Documents/ascend`).
2. Open Acode → menu → **Open folder** → choose `ascend/site`.
3. Open `index.html`. Tap the **⋮ menu → Run** (play icon) to preview in the built-in browser. Everything works offline, and the Buy button shows the disabled message.
4. Edit `config.js`: change `CONTACT_EMAIL` to your real email.

## Part 3 — Publish the website free

Easiest on a phone: **GitHub + Cloudflare Pages** (supports the security `_headers` file).

1. Create a free GitHub account, make a new **public or private** repository.
2. Upload the *contents* of `site/` (use the GitHub website → Add file → Upload files). Make sure `index.html` is at the top level.
3. Create a free Cloudflare account → **Workers & Pages → Create → Pages → Connect to Git** → pick the repo. Leave build command empty, output directory `/`. Deploy.
4. You get `https://something.pages.dev`. Note it down.

Alternative: GitHub Pages (also free) works, but ignores `_headers`.

## Part 4 — Things you need before taking real money

- **Razorpay account (or similar Indian provider).** The account holder must be an adult (18+) and complete KYC. Do not use someone else's account without their knowledge and consent. If you are under 18, a parent or guardian must own the merchant account and the legal responsibility.
- **Fees:** payment providers charge per transaction (Razorpay's standard rate is a percentage plus GST, and can change). Check the current pricing page. On a ₹149 product fees take a visible share.
- **Cloudflare free limits (can change):** Workers ≈ 100,000 requests/day, D1 and R2 have free allowances. R2 may ask for a payment method on file even when you stay inside the free tier. Check Cloudflare's pricing page.
- Policies in `site/` are templates. Read them, edit to match how you actually operate, and consider a legal check.

## Part 5 — Backend setup (all from a phone browser, Cloudflare dashboard)

**A. Database**
1. Dashboard → **Storage & Databases → D1 → Create database**, name `ascend-db`.
2. Open it → **Console**, paste the whole content of `worker/schema.sql`, run it.

**B. Private storage**
1. **R2 → Create bucket**, name `ascend-private`. Keep it **private** (do not enable public access / r2.dev).
2. Upload your finished PDF and name it exactly `ascend-guide.pdf`.

**C. The Worker**
1. **Workers & Pages → Create → Worker**, name `ascend-api`, Deploy, then **Edit code**.
2. Delete the sample and paste the full content of `worker/src/index.js`. Deploy.
3. Worker → **Settings → Bindings**: add **D1 database** (variable name `DB` → `ascend-db`) and **R2 bucket** (variable name `PDF_BUCKET` → `ascend-private`).
4. Worker → **Settings → Variables**: add
   - `ALLOWED_ORIGIN` = your site address, e.g. `https://something.pages.dev` (no trailing slash)
   - `PDF_KEY` = `ascend-guide.pdf`
5. Note the Worker address, e.g. `https://ascend-api.yourname.workers.dev`.

## Part 6 — Activate UPI checkout (test mode first)

1. In Razorpay Dashboard, switch to **Test Mode**. Settings → API Keys → generate keys.
2. In the Worker → Settings → Variables, add these as **Secrets** (encrypted):
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`
   - `RAZORPAY_WEBHOOK_SECRET` (you choose a long random string; use the same in step 3)
3. Razorpay → Settings → **Webhooks → Add**:
   - URL: `https://ascend-api.yourname.workers.dev/api/webhook`
   - Secret: the same `RAZORPAY_WEBHOOK_SECRET`
   - Events: `payment.captured` and `order.paid`
4. Razorpay → Settings → Payment capture: set to **automatic** so successful payments become `captured`.
5. In `site/config.js` set `API_BASE` to your Worker address, re-upload to GitHub. The site redeploys.
6. Test with Razorpay's test UPI details (see their docs). Confirm the download works, then try opening an old link after 10 minutes (it should say expired).
7. For live money: complete KYC, switch to **Live Mode**, generate live keys, replace the three secrets, create the webhook again in Live Mode. Do one small real purchase yourself and refund it.

## Part 7 — Security notes

- No secrets exist in `site/`. The Razorpay *key ID* sent to the browser is public by design; the key *secret* and webhook secret live only in Worker secrets.
- A "payment successful" message in the browser never unlocks anything; only the server-verified `paid` status does.
- Add a Cloudflare **Rate limiting rule** on `/api/create-order` for extra protection (dashboard → Security).
- Delivery tokens are stored only as hashes. A buyer who loses their order link and browser storage must contact you with order ID and email; you can look them up in the D1 console. (Emailing links needs an email service, which is an optional upgrade.)
- Never put the PDF in `site/`, GitHub, or a public bucket.

## Part 8 — Before launch checklist

- [ ] `CONTACT_EMAIL` changed
- [ ] Real PDF uploaded to the private bucket
- [ ] Policies reviewed
- [ ] Test-mode purchase and download worked
- [ ] Live keys and live webhook set
- [ ] One real ₹149 test purchase done
