-- ASCEND. database schema (Cloudflare D1 / SQLite). Run once.

CREATE TABLE IF NOT EXISTS orders (
  id            TEXT PRIMARY KEY,           -- our unique order ID (UUID)
  rz_order_id   TEXT NOT NULL UNIQUE,       -- payment provider's order ID
  email         TEXT NOT NULL,
  amount        INTEGER NOT NULL,           -- in paise (14900 = Rs 149)
  currency      TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'created',  -- created | paid | mismatch
  token_hash    TEXT NOT NULL,              -- SHA-256 of the buyer's delivery token
  payment_id    TEXT UNIQUE,                -- provider payment ID once paid
  created_at    INTEGER NOT NULL,
  paid_at       INTEGER
);

CREATE TABLE IF NOT EXISTS webhook_events (
  event_id      TEXT PRIMARY KEY,           -- provider event ID (dedupe)
  event_type    TEXT,
  received_at   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS downloads (
  ticket_hash   TEXT PRIMARY KEY,           -- SHA-256 of the short-lived ticket
  order_id      TEXT NOT NULL,
  expires_at    INTEGER NOT NULL,
  uses          INTEGER NOT NULL DEFAULT 0,
  max_uses      INTEGER NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_downloads_order ON downloads(order_id);
