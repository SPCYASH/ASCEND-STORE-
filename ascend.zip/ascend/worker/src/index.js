/**
 * ASCEND. backend — Cloudflare Worker.
 *
 * Endpoints
 *   GET  /api/config         -> is checkout configured? (public key id only)
 *   POST /api/create-order   -> creates a Razorpay order + a local order row
 *   POST /api/webhook        -> Razorpay signed webhook (the authority on payment)
 *   POST /api/status         -> order status (needs order id + delivery token)
 *   POST /api/download-link  -> short-lived download ticket (only if paid)
 *   GET  /api/d/<ticket>     -> streams the private PDF from R2
 *
 * Bindings (see wrangler.toml / README):
 *   DB          D1 database
 *   PDF_BUCKET  private R2 bucket
 * Secrets:
 *   RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET
 * Variables:
 *   ALLOWED_ORIGIN (your website origin), PDF_KEY (file name inside the bucket)
 */

const PRICE_PAISE = 14900;       // ₹149.00 — the price lives on the SERVER, never in the browser.
const CURRENCY = 'INR';
const TICKET_TTL_SECONDS = 600;  // download links last 10 minutes
const TICKET_MAX_USES = 5;       // retries for flaky mobile downloads

const encoder = new TextEncoder();

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    try {
      if (request.method === 'OPTIONS') return withCors(env, new Response(null, { status: 204 }));

      if (path === '/api/config' && request.method === 'GET') return withCors(env, handleConfig(env));
      if (path === '/api/create-order' && request.method === 'POST') return withCors(env, await handleCreateOrder(request, env));
      if (path === '/api/status' && request.method === 'POST') return withCors(env, await handleStatus(request, env));
      if (path === '/api/download-link' && request.method === 'POST') return withCors(env, await handleDownloadLink(request, env, url));
      if (path === '/api/webhook' && request.method === 'POST') return await handleWebhook(request, env); // server-to-server, no CORS
      if (path.startsWith('/api/d/') && request.method === 'GET') return await handleDownload(path.slice('/api/d/'.length), env);

      return withCors(env, json({ error: 'Not found' }, 404));
    } catch (err) {
      console.error('Unhandled error:', err && err.stack ? err.stack : err);
      return withCors(env, json({ error: 'Server error. Please try again.' }, 500));
    }
  },
};

/* ------------------------------------------------------------------ */
/* Handlers                                                           */
/* ------------------------------------------------------------------ */

function isConfigured(env) {
  return Boolean(env.RAZORPAY_KEY_ID && env.RAZORPAY_KEY_SECRET && env.RAZORPAY_WEBHOOK_SECRET && env.DB && env.PDF_BUCKET);
}

function handleConfig(env) {
  const on = isConfigured(env);
  return json({ checkoutEnabled: on, keyId: on ? env.RAZORPAY_KEY_ID : null, amount: PRICE_PAISE, currency: CURRENCY });
}

async function handleCreateOrder(request, env) {
  if (!isConfigured(env)) return json({ error: 'Checkout is not active.' }, 503);

  const body = await readJson(request);
  const email = String((body && body.email) || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 254) {
    return json({ error: 'Please enter a valid email address.' }, 400);
  }

  const orderRef = crypto.randomUUID();
  const deliveryToken = randomToken(32);

  // Amount and currency are fixed here. The browser cannot change them.
  const rz = await razorpay(env, '/orders', {
    method: 'POST',
    body: JSON.stringify({
      amount: PRICE_PAISE,
      currency: CURRENCY,
      receipt: orderRef.slice(0, 40),
      notes: { order_ref: orderRef },
    }),
  });
  if (!rz.ok) {
    console.error('Razorpay order error', rz.status, await rz.text());
    return json({ error: 'Could not start payment. Please try again in a moment.' }, 502);
  }
  const rzOrder = await rz.json();

  await env.DB.prepare(
    `INSERT INTO orders (id, rz_order_id, email, amount, currency, status, token_hash, created_at)
     VALUES (?, ?, ?, ?, ?, 'created', ?, ?)`
  ).bind(orderRef, rzOrder.id, email, PRICE_PAISE, CURRENCY, await sha256Hex(deliveryToken), now()).run();

  return json({
    orderRef,
    deliveryToken,                 // shown to the buyer once; only its hash is stored
    razorpayOrderId: rzOrder.id,
    keyId: env.RAZORPAY_KEY_ID,    // public identifier, safe for the browser
    amount: PRICE_PAISE,
    currency: CURRENCY,
  });
}

async function handleWebhook(request, env) {
  if (!isConfigured(env)) return new Response('Not configured', { status: 503 });

  // 1. Verify the provider's signature over the RAW body BEFORE touching anything.
  const raw = await request.text();
  const signature = request.headers.get('x-razorpay-signature') || '';
  const valid = await verifyHmacHex(env.RAZORPAY_WEBHOOK_SECRET, raw, signature);
  if (!valid) return new Response('Invalid signature', { status: 401 });

  let event;
  try { event = JSON.parse(raw); } catch { return new Response('Bad JSON', { status: 400 }); }

  const eventId = request.headers.get('x-razorpay-event-id') || '';
  const type = event && event.event;

  // 2. Duplicate delivery? Acknowledge without reprocessing.
  if (eventId) {
    const seen = await env.DB.prepare('SELECT 1 AS x FROM webhook_events WHERE event_id = ?').bind(eventId).first();
    if (seen) return new Response('Duplicate ignored', { status: 200 });
  }

  // 3. Only payment-success events matter.
  if (type === 'payment.captured' || type === 'order.paid') {
    const payment = event.payload && event.payload.payment && event.payload.payment.entity;
    if (payment) await applyVerifiedPayment(env, payment);
  }

  // 4. Record the event only after successful processing (so failures get retried by the provider).
  if (eventId) {
    await env.DB.prepare('INSERT OR IGNORE INTO webhook_events (event_id, event_type, received_at) VALUES (?, ?, ?)')
      .bind(eventId, String(type || ''), now()).run();
  }
  return new Response('OK', { status: 200 });
}

async function handleStatus(request, env) {
  const body = await readJson(request);
  const order = await authorizedOrder(env, body);
  if (order.error) return json({ error: order.error }, order.code);

  let status = order.row.status;

  // Safety net if the webhook is delayed: ask Razorpay directly (server-to-server, still verified).
  if (status === 'created' && isConfigured(env)) {
    try {
      const r = await razorpay(env, `/orders/${encodeURIComponent(order.row.rz_order_id)}/payments`, { method: 'GET' });
      if (r.ok) {
        const data = await r.json();
        const captured = (data.items || []).find((p) => p.status === 'captured');
        if (captured) {
          await applyVerifiedPayment(env, captured);
          const fresh = await env.DB.prepare('SELECT status FROM orders WHERE id = ?').bind(order.row.id).first();
          status = fresh ? fresh.status : status;
        }
      }
    } catch (e) {
      console.error('Reconcile failed', e);
    }
  }
  return json({ status });
}

async function handleDownloadLink(request, env, url) {
  const body = await readJson(request);
  const order = await authorizedOrder(env, body);
  if (order.error) return json({ error: order.error }, order.code);
  if (order.row.status !== 'paid') return json({ error: 'Payment is not verified yet.' }, 402);

  const ticket = randomToken(32);
  const expires = now() + TICKET_TTL_SECONDS;
  await env.DB.prepare(
    'INSERT INTO downloads (ticket_hash, order_id, expires_at, uses, max_uses, created_at) VALUES (?, ?, ?, 0, ?, ?)'
  ).bind(await sha256Hex(ticket), order.row.id, expires, TICKET_MAX_USES, now()).run();

  return json({ url: `${url.origin}/api/d/${ticket}`, expiresInSeconds: TICKET_TTL_SECONDS });
}

async function handleDownload(ticket, env) {
  if (!/^[A-Za-z0-9_-]{20,80}$/.test(ticket)) return plain('Invalid link', 400);

  const hash = await sha256Hex(ticket);
  const row = await env.DB.prepare('SELECT order_id, expires_at, uses, max_uses FROM downloads WHERE ticket_hash = ?').bind(hash).first();
  if (!row) return plain('Link not found', 404);
  if (row.expires_at < now()) return plain('This download link has expired. Open your order page and request a new one.', 410);

  // Atomic use counter: protects against duplicate/parallel requests beyond the allowed number.
  const upd = await env.DB.prepare(
    'UPDATE downloads SET uses = uses + 1 WHERE ticket_hash = ? AND uses < max_uses AND expires_at >= ?'
  ).bind(hash, now()).run();
  if (!upd.meta || upd.meta.changes !== 1) return plain('This link has been used too many times. Request a new one from your order page.', 410);

  // Re-check the order is still paid (e.g. not later flagged).
  const order = await env.DB.prepare('SELECT status FROM orders WHERE id = ?').bind(row.order_id).first();
  if (!order || order.status !== 'paid') return plain('Order not eligible', 403);

  const object = await env.PDF_BUCKET.get(env.PDF_KEY || 'ascend-guide.pdf');
  if (!object) return plain('File temporarily unavailable. Please contact support.', 503);

  const headers = new Headers({
    'Content-Type': 'application/pdf',
    'Content-Disposition': 'attachment; filename="ASCEND-Glow-Up-Guide.pdf"',
    'Cache-Control': 'private, no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
  });
  if (object.size) headers.set('Content-Length', String(object.size));
  return new Response(object.body, { status: 200, headers });
}

/* ------------------------------------------------------------------ */
/* Core payment logic — idempotent                                    */
/* ------------------------------------------------------------------ */

/**
 * Marks an order paid ONLY if every check passes:
 *  - the Razorpay order id is one we created,
 *  - payment status is 'captured',
 *  - amount equals what we stored (₹149 = 14900 paise),
 *  - currency is INR.
 * Safe to call many times for the same payment.
 */
async function applyVerifiedPayment(env, payment) {
  if (!payment || !payment.order_id) return;

  const row = await env.DB.prepare('SELECT id, amount, currency, status FROM orders WHERE rz_order_id = ?')
    .bind(payment.order_id).first();
  if (!row) return;                       // not an order of ours
  if (row.status === 'paid') return;      // already done (duplicate event)

  const ok = payment.status === 'captured'
    && Number(payment.amount) === row.amount
    && row.amount === PRICE_PAISE
    && payment.currency === row.currency
    && row.currency === CURRENCY;

  if (!ok) {
    if (payment.status === 'captured') {
      // Money arrived but the details are wrong: flag for manual review, never release the PDF.
      await env.DB.prepare("UPDATE orders SET status = 'mismatch', payment_id = ? WHERE id = ? AND status = 'created'")
        .bind(String(payment.id || ''), row.id).run();
    }
    return;
  }

  // Atomic transition: only one caller can move created -> paid.
  await env.DB.prepare(
    "UPDATE orders SET status = 'paid', payment_id = ?, paid_at = ? WHERE id = ? AND status = 'created'"
  ).bind(String(payment.id || ''), now(), row.id).run();
}

async function authorizedOrder(env, body) {
  const id = String((body && body.order) || '');
  const token = String((body && body.token) || '');
  if (!/^[0-9a-f-]{36}$/i.test(id) || token.length < 20 || token.length > 100) return { error: 'Invalid request', code: 400 };

  const row = await env.DB.prepare('SELECT id, rz_order_id, status, token_hash FROM orders WHERE id = ?').bind(id).first();
  if (!row) return { error: 'Order not found', code: 404 };
  // Both sides are fixed-length SHA-256 hex strings, so this comparison leaks nothing useful.
  if ((await sha256Hex(token)) !== row.token_hash) return { error: 'Not allowed', code: 403 };
  return { row };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

function razorpay(env, path, init) {
  const auth = btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);
  return fetch(`https://api.razorpay.com/v1${path}`, {
    ...init,
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
  });
}

async function verifyHmacHex(secret, message, signatureHex) {
  if (!/^[0-9a-f]{64}$/i.test(signatureHex)) return false;
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const sig = new Uint8Array(signatureHex.match(/../g).map((h) => parseInt(h, 16)));
  return crypto.subtle.verify('HMAC', key, sig, encoder.encode(message)); // constant-time
}

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', encoder.encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function randomToken(bytes) {
  const arr = crypto.getRandomValues(new Uint8Array(bytes));
  let s = '';
  for (const b of arr) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

const now = () => Math.floor(Date.now() / 1000);

async function readJson(request) {
  try {
    const text = await request.text();
    if (text.length > 10000) return null;
    return JSON.parse(text);
  } catch { return null; }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function plain(text, status) {
  return new Response(text, { status, headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' } });
}

function withCors(env, response) {
  const h = new Headers(response.headers);
  h.set('Access-Control-Allow-Origin', env.ALLOWED_ORIGIN || 'null');
  h.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  h.set('Access-Control-Allow-Headers', 'Content-Type');
  h.set('Access-Control-Max-Age', '86400');
  h.set('Vary', 'Origin');
  return new Response(response.body, { status: response.status, headers: h });
}
